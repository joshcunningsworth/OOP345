/*
 * Process.cpp
 *
 *
 *      Author: Josh
 */

#include "Process.h"
#include "CString.h"

void process(char* s){
	ws1::CString cs(s);
	std::cout << cs << "\n";
}
