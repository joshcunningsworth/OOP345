/*
 * Process.h
 *
 *
 *      Author: Josh
 */

#pragma once  // 2000 way of avoiding redefinition of file

#ifndef PROCESS_H_  // 1977 way of avoiding redefinition of file (if not defined)
#define PROCESS_H_
#include "iostream"

void process(char* s);


#endif /* PROCESS_H_ */
